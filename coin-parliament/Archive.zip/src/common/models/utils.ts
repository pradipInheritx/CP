export interface Callback<T> {
    successFunc: (params: T) => void;
    errorFunc: (error: Error, params?: T) => void;
}
