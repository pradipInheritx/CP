export const vote = {
  userId: "8HDeNuCpyusuG7ObjzbdPzRyVhYC",
  timeframe: {
    index: 0,
    chosen: true,
    seconds: 15,
    name: "15 seconds",
  },
  coin: "REEF-FTM",
  direction: 0,
  status: {
    color: "2",
    givenCPM: 1,
    index: 0,
    weight: 1,
    name: "Member",
    share: "50",
  },
};
