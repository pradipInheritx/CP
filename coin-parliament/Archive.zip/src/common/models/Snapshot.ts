export type WSnap = { id: string };
