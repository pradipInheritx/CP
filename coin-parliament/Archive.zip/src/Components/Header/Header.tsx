export enum HeaderTypes {
  HOMEPAGE,
  REGULAR,
}
export type HeaderProps = {
  type: HeaderTypes;
};

const Header = ({}: HeaderProps) => {};
