import React from "react";

const CalculatingVotes = () => {
  return (
    <React.Fragment>
      <div
        className="d-flex justify-content-center align-items-center w-100 text-center"
        style={{height: 100}}
      >
        <div className="blink m-5">Calculating Votes</div>
      </div>
    </React.Fragment>
  );
};

export default CalculatingVotes;
