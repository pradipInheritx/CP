import TextField, { TextFieldProps } from "../Forms/Textfield";
import React from "react";

const TF = (props: TextFieldProps) => <TextField {...props} color="white" />;

export default TF;
