import styled from "styled-components";

const h1 = styled.h1``;

const h2 = styled.h2``;

const h3 = styled.h3``;

const h4 = styled.h4``;

const h5 = styled.h5``;

const h6 = styled.h6``;

const p = styled.p``;

const span = styled.span``;

export default {
  h1,
  h2,
  h3,
  h4,
  h5,
  h6,
  p,
  span,
};
